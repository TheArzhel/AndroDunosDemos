SQUARE ART
using SDL libraries.

use the .exe to see art

by Andres Saladrigas