by Andres Saladrigas. 
i dont own any of the sprites.
